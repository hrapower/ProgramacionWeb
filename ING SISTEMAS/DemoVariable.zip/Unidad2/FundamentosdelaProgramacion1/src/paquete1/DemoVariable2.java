package paquete1;

public class DemoVariable2 {

}
